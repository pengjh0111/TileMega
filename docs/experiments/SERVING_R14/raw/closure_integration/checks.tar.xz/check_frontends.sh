#!/bin/bash
set -euo pipefail
ctest --test-dir /root/r14_work/closure_checks/build --output-on-failure -R '^(bound_dependency_codegen|operator_classes|dm_operator_classes|moe_structure_search|dnn_semantic_lifting|dnn_model_plan|moe_region_plan|dnn_structure_search|moe_semantic_lifting)$'
touch /root/r14_work/closure_checks/frontends.done
