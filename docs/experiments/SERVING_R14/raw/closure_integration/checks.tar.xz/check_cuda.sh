#!/bin/bash
set -euo pipefail
cd /root/r14_work/closure_integration
OUT=/root/r14_work/closure_checks
CUDA=/usr/local/cuda/bin/nvcc
COMMON=(-std=c++17 -arch=sm_89 --expt-relaxed-constexpr -Iinclude -I"$OUT/build/include" -Ithird_party/cutlass/include -Ithird_party/cutlass/tools/util/include -Ithird_party/cutlass/test)
"$CUDA" "${COMMON[@]}" -c test/unit/attention_layout_test.cu -o "$OUT/r14_attention.o"
"$CUDA" "${COMMON[@]}" -c test/unit/serving_gemv_test.cu -o "$OUT/r14_gemv.o"
"$CUDA" "${COMMON[@]}" -DTILEMEGA_ARCH_ID=890 -c test/unit/dm_gemv_compile.cu -o "$OUT/dm_gemv.o"
"$CUDA" "${COMMON[@]}" -DTILEMEGA_DM_SUPPORT=1 -DDM_TEST_ATTN_MODE=3 -c test/unit/dm_qperkv8_attention_test.cu -o "$OUT/dm_attention.o"
touch "$OUT/cuda.done"
