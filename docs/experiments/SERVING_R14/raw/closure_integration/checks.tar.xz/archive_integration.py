"""Archive compile/host evidence without executing any CUDA kernels."""
import hashlib,json,re,subprocess,tarfile
from pathlib import Path

ROOT=Path('/root/r14_work/closure_integration')
CHECK=Path('/root/r14_work/closure_checks')
OUT=ROOT/'docs/experiments/SERVING_R14/raw/closure_integration'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def git(*args):return subprocess.check_output(['git','-C',str(ROOT),*args],text=True).strip()
for name in ('build','cuda','python','final_host','harness'):
    assert (CHECK/(name+'.done')).exists(),name
host=(CHECK/'final_host.log').read_text()
assert '100% tests passed, 0 tests failed out of 11' in host
fingerprints=re.findall(r'PASS source fingerprint (\w+)',host)
assert fingerprints
frontend=(CHECK/'frontends.log').read_text()
extra_passed=len(re.findall(r'Test\s+#\d+:.*?Passed',frontend))
py=(CHECK/'python.log').read_text()
assert 'FAILED' not in py
python_count=sum(map(int,re.findall(r'Ran (\d+) tests',py)))
assert python_count==45
OUT.mkdir(parents=True,exist_ok=True)
files=[p for p in CHECK.iterdir() if p.is_file() and p.suffix in ('.py','.sh','.json','.log','.done')]
fixture=ROOT/'docs/experiments/SEQSCAN/raw/export/gqa2.json'
members=[]
with tarfile.open(OUT/'checks.tar.xz','w:xz',preset=3) as tar:
    for p in sorted(files):
        tar.add(p,arcname=p.name,recursive=False)
        members.append(dict(source=str(p),member=p.name,sha256=sha(p),bytes=p.stat().st_size))
    tar.add(fixture,arcname='fixtures/gqa2.json',recursive=False)
    members.append(dict(source=str(fixture.resolve()),member='fixtures/gqa2.json',sha256=sha(fixture),bytes=fixture.stat().st_size))
artifacts=[p for p in CHECK.glob('*.o')]+[CHECK/'build/tools/tilemega',CHECK/'build/tilemega-unit']
artifacts=[p for p in artifacts if p.is_file()]
contracts=json.loads((CHECK/'contracts.json').read_text())
report=dict(status='compile_and_host_checks_pass; no_post_merge_GPU_execution',
    source_head=git('rev-parse','HEAD'),r14_frozen='97f7a2f1d',r14_closeout='688ac56a0',
    preserved_remote='a3f0dc6d10c368dbbe3073c66cc750aec92a70a3',
    preserved_dm='0e64c56b010488a7229a75ed79814fb865aef197',
    source_fingerprint=fingerprints[-1],host_ctest_passed=11+extra_passed,python_tests_passed=python_count,
    optional_frontend_check=dict(requested=9,passed=extra_passed,complete=(CHECK/'frontends.done').exists(),
        limit_seconds=300,uncompleted='40-family moe_structure_search did not complete within the bounded CPU command; later optional checks were not reached'),
    cuda_compile_only=dict(arch='sm_89',unit_sources=['attention_layout_test.cu','serving_gemv_test.cu','dm_gemv_compile.cu','dm_qperkv8_attention_test.cu'],
        full_runtime_sources=['forward_runtime_test.cu','dm_nonpaged_attention_handoff_test.cu'],
        r14_generated_control='logic_completion_arms.json:llama_B1; original CU with integrated headers'),
    compatibility_contracts=contracts,
    submodules={s:git('ls-files','-s','third_party/'+s).split()[1] for s in ('cutlass','barvinok')},
    limitation='Historical GPU evidence binds frozen pre-merge source. No new synchronization reliability or performance acceptance is claimed. Historical five-architecture compilation is not post-merge hardware validation.',
    initial_failures=['duplicate CMake test/runner registrations','missing handoff paged variable','four-field initializer after tuple extension','missing host fixture and model config fixture','DM combine used R14-only SwigLU macro','compile-only adaptation initially retained multiple host link inputs; corrected to one generated CUDA TU'],
    resolutions='Source unions plus TILEMEGA_DM_SUPPORT-gated bodies; separate artifact schema APIs; optional host-only execution introspection; preserved runtime headers verified against each branch.',
    artifacts=[dict(path=str(p),sha256=sha(p),bytes=p.stat().st_size) for p in artifacts],
    archive=dict(path='checks.tar.xz',sha256=sha(OUT/'checks.tar.xz'),members=members))
(OUT/'acceptance.json').write_text(json.dumps(report,indent=2)+'\n')
with tarfile.open(OUT/'checks.tar.xz') as tar:
    for row in members:
        assert hashlib.sha256(tar.extractfile(row['member']).read()).hexdigest()==row['sha256']
print(json.dumps(dict(host=11+extra_passed,python=python_count,contracts=contracts['count'],archive_members=len(members),archive_bytes=(OUT/'checks.tar.xz').stat().st_size)))
