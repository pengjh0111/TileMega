#!/bin/bash
set -euo pipefail
cd /root/r14_work/closure_integration
export PYTHONPATH=$PWD/python
P=/root/venvs/tilemega-torch213-cu126/bin/python
for f in serving_identity integrated_selection serving_build_orchestration; do "$P" test/python/$f.py; done
for f in test_attention_selection test_serving_prefill_choices test_moe_full test_dnn_cli test_dm_serving_identity_compat; do "$P" -m unittest discover -s test/python -p "$f.py"; done
touch /root/r14_work/closure_checks/python.done
