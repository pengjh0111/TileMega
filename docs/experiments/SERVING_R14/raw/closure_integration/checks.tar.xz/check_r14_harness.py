import json,shlex,subprocess
from pathlib import Path
root=Path('/root/r14_work/closure_integration');out=Path('/root/r14_work/closure_checks')
arms=json.loads((root/'docs/experiments/SERVING_R14/logic_completion_arms.json').read_text())
so=Path(arms['llama_B1']['decode']);command=shlex.split(Path(str(so)+'.build_command.txt').read_text())
args=[]
for word in command:
    if word=='-shared':continue
    args.append(word.replace('-I/root/TileMega/include','-I'+str(root/'include')).replace('-I/root/TileMega/build-phase12/include','-I'+str(out/'build/include')))
    if word.endswith('.cu'):break  # Compile one TU; the recorded link command also has host .cpp files.
args.insert(1,'-c');args+=['-o',str(out/'r14_harness.o')]
(out/'r14_harness_command.json').write_text(json.dumps(args,indent=2)+'\n')
subprocess.run(args,check=True,cwd=root)
(out/'harness.done').touch()
print('PASS integrated R14 generated control compilation; both DM runtime TUs compiled separately')
