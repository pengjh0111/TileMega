#!/bin/bash
set -euo pipefail
cd /root/r14_work/closure_integration
cmake --build /root/r14_work/closure_checks/build --target tilemega tilemega-unit -j 6
ctest --test-dir /root/r14_work/closure_checks/build --output-on-failure -R '^(stage_flow|attention_page_layout|dm_attention_page_layout|dm_page_layout|serving_attention_legality|handoff_ir|dm_gemm_traits|dm_gemm_candidates|dm_gemm_class_domain|dm_forward_search|dm_page_resources)$'
PYTHONPATH=$PWD/python /root/venvs/tilemega-torch213-cu126/bin/python python/tilemega/fingerprint.py --check /root/r14_work/closure_checks/build/tools/tilemega
touch /root/r14_work/closure_checks/final_host.done
