#!/bin/bash
set -euo pipefail
cd /root/r14_work/closure_integration
OUT=/root/r14_work/closure_checks
CUDA=/usr/local/cuda/bin/nvcc
COMMON=(-std=c++17 -arch=sm_89 --expt-relaxed-constexpr -Iinclude -I"$OUT/build/include" -Ithird_party/cutlass/include -Ithird_party/cutlass/tools/util/include -Ithird_party/cutlass/test)
"$CUDA" "${COMMON[@]}" -c test/unit/forward_runtime_test.cu -o "$OUT/dm_forward_runtime.o"
"$CUDA" "${COMMON[@]}" -c test/unit/dm_nonpaged_attention_handoff_test.cu -o "$OUT/dm_attention_handoff.o"
python3 - <<'PY'
import json,shlex,subprocess
from pathlib import Path
root=Path.cwd();out=Path('/root/r14_work/closure_checks')
arms=json.loads((root/'docs/experiments/SERVING_R14/logic_completion_arms.json').read_text())
so=Path(arms['llama_B1']['decode']);command=shlex.split(Path(str(so)+'.build_command.txt').read_text())
args=[]
for word in command:
 if word=='-shared':continue
 args.append(word.replace('-I/root/TileMega/include','-I'+str(root/'include')).replace('-I/root/TileMega/build-phase12/include','-I'+str(out/'build/include')))
args[args.index('-o')+1]=str(out/'r14_harness.o');args.insert(1,'-c')
(out/'r14_harness_command.json').write_text(json.dumps(args,indent=2)+'\n')
subprocess.run(args,check=True)
PY
touch "$OUT/harness.done"
