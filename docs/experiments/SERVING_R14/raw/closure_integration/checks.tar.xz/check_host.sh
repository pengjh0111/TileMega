#!/bin/bash
set -euo pipefail
export PYTHONPATH=/root/r14_work/closure_integration/python
export PATH=/usr/local/cuda/bin:$PATH
cd /root/r14_work/closure_integration
cmake --build /root/r14_work/closure_checks/build --target tilemega tilemega-unit -j 6
ctest --test-dir /root/r14_work/closure_checks/build --output-on-failure -R '^(stage_flow|attention_page_layout|dm_attention_page_layout|dm_page_layout|serving_attention_legality|handoff_ir|dm_gemm_traits|dm_gemm_candidates|dm_gemm_class_domain|dm_forward_search|dm_page_resources)$'
P=/root/venvs/tilemega-torch213-cu126/bin/python
for f in serving_identity integrated_selection serving_build_orchestration; do "$P" test/python/$f.py; done
for f in test_attention_selection test_serving_prefill_choices test_moe_full test_dnn_cli test_dm_serving_identity_compat; do "$P" -m unittest discover -s test/python -p "$f.py"; done
"$P" python/tilemega/fingerprint.py --check /root/r14_work/closure_checks/build/tools/tilemega
touch /root/r14_work/closure_checks/host.done
